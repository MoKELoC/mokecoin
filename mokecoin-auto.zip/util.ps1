Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=71246e2f86ad226006d0cb698667a3dd1b6a1e05e0828fe90b&filename=mokecoin-qt-windows.zip" -OutFile "$HOME\Downloads\mokecoin-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\mokecoin-qt-windows.zip" -DestinationPath "$HOME\Desktop\Mokecoin"

$ConfigFile = "rpcuser=rpc_mokecoin
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=0.0.0.0
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node2.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "Mokecoin" -ItemType "directory"
New-Item -Path "$env:appdata\Mokecoin" -Name "Mokecoin.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('mokecoin-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 mokecoin-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\Mokecoin" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\Mokecoin\mokecoin-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\Mokecoin\"
Start-Process "mine.bat"